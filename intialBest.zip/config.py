OPENROUTER_API_KEY  = "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"
#MONGO_URI =" mongodb://localhost:27017"

#DB_Name = "echatbot"

FAQ_CSV_PATH = "netsol_faqs.csv"       
EMBEDDING_MODEL = "nvidia/llama-nemotron-embed-vl-1b-v2:free"
RAG_TOP_K = 2 
