
import streamlit as st
import requests
import json
import time

st.set_page_config(page_title="eChatBot", page_icon="🤖")
st.title("eChatBot")

st.markdown("""
<style>
.chat-row {
    display: flex;
    margin: 8px 0;
}
.chat-row.user {
    justify-content: flex-end;
}
.chat-row.assistant {
    justify-content: flex-start;
}
.bubble {
    padding: 10px 16px;
    border-radius: 16px;
    max-width: 70%;
    word-wrap: break-word;
}
.bubble.user {
    background-color: #2563eb;
    color: white;
    border-bottom-right-radius: 4px;
}
.bubble.assistant {
    background-color: #f1f1f1;
    color: #111;
    border-bottom-left-radius: 4px;
}
</style>
""", unsafe_allow_html=True)

def render_bubble(role, content):
    return f"""
    <div class="chat-row {role}">
        <div class="bubble {role}">{content}</div>
    </div>
    """
    
if "messages" not in st.session_state:
    st.session_state.messages = []
if "conversation_id" not in st.session_state:
    st.session_state.conversation_id = "conv_001"

@st.dialog("Confirm deletion")
def confirm_delete(cid):
    st.warning(f"This will permanently delete all messages in conversation **{cid}**. This cannot be undone.")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Cancel"):
            st.rerun()
    with col2:
        if st.button("Yes, delete it", type="primary"):
            requests.delete(f"http://localhost:8000/delete/{cid}")
            st.session_state.messages = []
            st.rerun()
            
# Sidebar
with st.sidebar:
    st.header("sideBar")
    
    # c1 , c2 = st.columns(2)
    # with c1:
    #     if st.but
    
    cid = st.text_input("Conversation ID:", value=st.session_state.conversation_id)
    if st.button("Switch Convo"):
        if cid != st.session_state.conversation_id or True:
            st.session_state.conversation_id = cid
            st.session_state.messages = []
            # Load existing conversation
            try:
                response = requests.get(f"http://localhost:8000/get/{cid}")
                if response.status_code == 200:
                    history = response.json()
                    
                    st.session_state.messages = history
                    # for msg in history:
                    #     st.session_state.messages.append(msg)
            except:
                pass
            st.rerun()
    
    if st.button("Clear Chat"):
        response = requests.delete(f"http://localhost:8000/delete/{cid}")
        st.session_state.messages = []
        st.rerun()

# Display messages
for msg in st.session_state.messages:
    st.markdown(render_bubble(msg["role"], msg["content"]), unsafe_allow_html=True)


# Chat input
if prompt := st.chat_input("Type your message..."):
    # Add user message
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.markdown(render_bubble("user", prompt), unsafe_allow_html=True)

    message_placeholder = st.empty()
    
    full_response = ""
        
    try:
            # Use streaming endpoint
            response = requests.post(
                "http://localhost:8000/post_stream",
                json={
                    "Cid": st.session_state.conversation_id,
                    "role": "user",
                    "content": prompt
                },
                stream=True
            )
            
            if response.status_code == 200:
                counter = 0
                for line in response.iter_lines(chunk_size=1):
                    if line:
                        line = line.decode('utf-8')
                        if line.startswith('data: '):
                            data = line[6:]
                            if data == '[DONE]':
                                break
                            full_response += data
                            counter += 1
                            
                            if counter % 3 ==0:
                                message_placeholder.markdown(render_bubble("assistant", full_response + "▌"), unsafe_allow_html=True)                
                message_placeholder.markdown(render_bubble("assistant",full_response),unsafe_allow_html=True)
                st.session_state.messages.append({"role": "assistant", "content": full_response})
            else:
                st.error(f"Error: {response.status_code}")
                
    except requests.exceptions.ConnectionError:
        st.error("❌ Cannot connect to server. Make sure FastAPI is running!")
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")

